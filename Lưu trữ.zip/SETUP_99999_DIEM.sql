-- FISH MOD Z: cấp 99.999 điểm cho mỗi tài khoản mới.
-- Chạy trong Supabase Dashboard > SQL Editor.
-- Trigger chạy cho mọi tài khoản Auth mới (đăng ký mật khẩu hoặc Google).
create or replace function public.fish_grant_initial_points()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.fish_wallets (user_id, points)
  values (new.id, 99999)
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists fish_grant_initial_points_after_signup on auth.users;
create trigger fish_grant_initial_points_after_signup
after insert on auth.users
for each row execute function public.fish_grant_initial_points();
